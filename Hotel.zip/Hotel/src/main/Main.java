package main;

import object.Hotel;
import object.Room;
import object.Booking;
import java.time.LocalDate;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Hotel hotel = new Hotel();
        Scanner scanner = new Scanner(System.in);

        hotel.addRoom(101, "Single", 100.0);
        hotel.addRoom(102, "Double", 150.0);
        hotel.addRoom(103, "Suite", 200.0);

        boolean isRunning = true;

        while (isRunning) {
            System.out.println("\nHotel Management System");
            System.out.println("1. Create Booking");
            System.out.println("2. Process Check-out");
            System.out.println("3. View Room Occupancy");
            System.out.println("4. View Booking History");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();

            switch (option) {
                case 1:
                    System.out.print("Guest name: ");
                    String guestName = scanner.next();
                    System.out.print("Check-in date (YYYY-MM-DD): ");
                    LocalDate checkInDate = LocalDate.parse(scanner.next());
                    System.out.print("Check-out date (YYYY-MM-DD): ");
                    LocalDate checkOutDate = LocalDate.parse(scanner.next());
                    System.out.print("Room number: ");
                    int roomNumber = scanner.nextInt();
                    hotel.createBooking(guestName, checkInDate, checkOutDate, roomNumber);
                    break;

                case 2:
                    System.out.print("Room number for check-out: ");
                    int roomForCheckOut = scanner.nextInt();
                    hotel.processCheckOut(roomForCheckOut);
                    break;

                case 3:
                    hotel.listRoomOccupancy();
                    break;

                case 4:
                    hotel.showBookingHistory();
                    break;

                case 5:
                    isRunning = false;
                    break;

                default:
                    System.out.println("Invalid option.");
            }
        }

        scanner.close();
    }
}
