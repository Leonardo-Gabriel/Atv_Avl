/**
 * 
 */
/**
 * 
 */
module Hotel {
}