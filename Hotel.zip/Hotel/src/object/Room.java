package object;

public class Room {
    public int roomNumber;
    public String roomType;
    public double dailyRate;
    public boolean isAvailable;

    public Room(int roomNumber, String roomType, double dailyRate) {
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.dailyRate = dailyRate;
        this.isAvailable = true;
    }

    public void occupy() {
        this.isAvailable = false;
    }

    public void freeUp() {
        this.isAvailable = true;
    }


    public String toString() {
        return "Room " + roomNumber + " (" + roomType + ") - " + (isAvailable ? "Available" : "Occupied");
    }
}
