package object;

import java.time.LocalDate;  // Adicione esta importação
import java.util.ArrayList;
import java.util.List;

public class Hotel {
    public List<Room> rooms = new ArrayList<>();
    public List<Booking> bookings = new ArrayList<>();

    public void addRoom(int roomNumber, String roomType, double dailyRate) {
        Room room = new Room(roomNumber, roomType, dailyRate);
        rooms.add(room);
    }

    public void createBooking(String guestName, LocalDate checkInDate, LocalDate checkOutDate, int roomNumber) {
        Room room = findRoomByNumber(roomNumber);
        if (room != null && room.isAvailable) {
            room.occupy();
            Booking booking = new Booking(guestName, checkInDate, checkOutDate, room);
            bookings.add(booking);
            System.out.println("Booking created successfully!");
        } else {
            System.out.println("Room is unavailable.");
        }
    }

    public void processCheckOut(int roomNumber) {
        Room room = findRoomByNumber(roomNumber);
        if (room != null) {
            room.freeUp();
            System.out.println("Check-out completed successfully!");
        } else {
            System.out.println("Room not found.");
        }
    }

    public void listRoomOccupancy() {
        System.out.println("Current room occupancy:");
        for (Room room : rooms) {
            System.out.println(room);
        }
    }

    public void showBookingHistory() {
        System.out.println("Booking history:");
        for (Booking booking : bookings) {
            System.out.println(booking);
        }
    }

    private Room findRoomByNumber(int roomNumber) {
        for (Room room : rooms) {
            if (room.roomNumber == roomNumber) {
                return room;
            }
        }
        return null;
    }
}
