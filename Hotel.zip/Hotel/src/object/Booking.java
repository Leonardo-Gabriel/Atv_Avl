package object;

import java.time.LocalDate;

public class Booking {
    public String guestName;
    public LocalDate checkInDate;
    public LocalDate checkOutDate;
    public Room room;

    public Booking(String guestName, LocalDate checkInDate, LocalDate checkOutDate, Room room) {
        this.guestName = guestName;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
        this.room = room;
    }

  
    public String toString() {
        return "Booking for " + guestName + " in room " + room.roomNumber +
               " from " + checkInDate + " to " + checkOutDate;
    }
}
